# PokeApi + React + Context

Solución propuesta para el Taller 2.

- Enunciado: https://docs.google.com/document/d/1NeDFVLDHG1XHFAQlmD08aYjcXZdLH3bZJFhJHmPt7c8/edit?usp=sharing
- Netlify: https://taller-2-solucion.netlify.app
